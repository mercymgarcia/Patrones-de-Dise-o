/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Decorador;

/**
 *
 * @author Sonia
 */
public abstract class Decorador extends Bebida{
    
    @Override
    public abstract String getDescripcion();
    
}
