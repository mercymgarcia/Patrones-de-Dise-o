/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patronesdediseño;

import Decorador.Bebida;
import Decorador.Espresso;
import Decorador.HouseBlend;

/**
 *
 * @author Sonia
 */
public class Patronesdediseño {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /*
        // Crear la estación de clima (el sujeto)
        EstacionClima estacionClima = new EstacionClima();
        /*SmartPhone smartPhone = new SmartPhone();
        
        // Crear un observador Incivumeh y registrarlo en la estación de clima
        Incivumeh incivumeh = new Incivumeh(estacionClima);
        
        // Cambiar las mediciones y ver cómo el observador es notificado
        estacionClima.setMediciones(12, 13, 14);
        estacionClima.setMediciones(15, 16, 17);
        */
      

                         
        // Crear una instancia de HouseBlend
        Bebida houseBlend = new HouseBlend();
        System.out.println(houseBlend.getDescripcion() + " GTQ " + houseBlend.precio());
               
        // Crear una instancia de Espresso
        Bebida espresso = new Espresso();
        System.out.println(espresso.getDescripcion() + " GTQ " + espresso.precio());   
         
    }
}
 


