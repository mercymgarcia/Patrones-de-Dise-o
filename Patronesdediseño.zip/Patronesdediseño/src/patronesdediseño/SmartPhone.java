/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronesdediseño;

/**
 *
 * @author Sonia
 */
public class SmartPhone implements Observador {
    private float humedad;
    private float temperatura;
    private float presion;
    private Sujeto sujeto;

    // Constructor de la clase SmartPhone
    public SmartPhone(Sujeto sujeto) {
        this.sujeto = sujeto;  // Se asigna el sujeto al atributo
        sujeto.registrarObservador(this);  // El SmartPhone se registra como observador
    }
        SmartPhone(EstacionClima estacionClima) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        
    // Método que se llama cuando hay un cambio en las condiciones climáticas
    @Override
    public void actualizar(float temperatura, float humedad, float presion) {
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.presion = presion;
        visualizar();  // Se muestra la nueva información al usuario
    }

    // Método para mostrar las condiciones climáticas actuales
    public void visualizar() {
        System.out.println("Condiciones Climáticas: " 
            + this.temperatura + " grados Celsius, " 
            + this.humedad + "% de humedad y " 
            + this.presion + " unidades de presión.");
    }    
}

