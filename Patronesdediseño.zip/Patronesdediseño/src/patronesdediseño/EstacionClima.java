/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronesdediseño;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sonia
 */
public class EstacionClima implements Sujeto {
    private List<Observador> observadores;
    private float temperatura;
    private float humedad;
    private float presion;

    public EstacionClima() {
        observadores = new ArrayList<>();
    }

    @Override
    public void registrarObservador(Observador o) {
        observadores.add(o);
    }

    @Override
    public void eliminarObservador(Observador o) {
        observadores.remove(o);
    }

    @Override
    public void notificarObservadores() {
        for (Observador observador : observadores) {
            observador.actualizar(temperatura, humedad, presion);
        }
    }

    public void setMediciones(float temperatura, float humedad, float presion) {
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.presion = presion;
        notificarObservadores(); // Notificar a todos los observadores cuando cambien las mediciones
    }
}

