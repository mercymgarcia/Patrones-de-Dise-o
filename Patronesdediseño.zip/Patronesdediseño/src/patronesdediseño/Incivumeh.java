/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronesdediseño;

/**
 *
 * @author Sonia
 */
public class Incivumeh implements Observador {
    private float humedad; //coreccion de la humedad a humedad
    private float temperatura;
    private float presion;
    private Sujeto sujeto;

    //constructor de la clase
    public Incivumeh(Sujeto sujeto) {
        this.sujeto = sujeto; 
        sujeto.registrarObservador(this); // Se registra como observador
    }

    @Override
    public void actualizar(float temperatura, float humedad, float presion) {
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.presion = presion;
        visualizar(); // Mostrar las nuevas condiciones climáticas
    }

    public void visualizar() {
        System.out.println("Condiciones Climaticas: " 
            + this.temperatura + " grados celcius, " 
            + this.humedad + "% de humedad y " 
            + this.presion + " unidades de presion.");
    }
}



